// User Registration
function register() {
  let username = document.getElementById("username").value.trim();
  let password = document.getElementById("password").value;
  let users = JSON.parse(localStorage.getItem("users")) || {};

  if (!username || !password) {
    document.getElementById("error-message").innerText = "Username and password cannot be empty!";
    return;
  }

  if (users[username]) {
    document.getElementById("error-message").innerText = "This username is already taken!";
    return;
  }

  users[username] = password;
  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("currentUser", username);
  window.location.href = "home.html";
}

// User Login
function login() {
  let username = document.getElementById("username").value.trim();
  let password = document.getElementById("password").value;
  let users = JSON.parse(localStorage.getItem("users")) || {};

  if (users[username] && users[username] === password) {
    localStorage.setItem("currentUser", username);
    window.location.href = "home.html";
  } else {
    document.getElementById("error-message").innerText = "Invalid username or password!";
  }
}

// Logout
function logout() {
  localStorage.removeItem("currentUser");
  window.location.href = "index.html";
}

// Add to Cart
function addToCart(productName, price) {
    let currentUser = localStorage.getItem("currentUser");
    if (!currentUser) {
        alert("Please log in first!");
        return;
    }

    let cart = JSON.parse(localStorage.getItem(currentUser + "_cart")) || [];
    cart.push({ name: productName, price: price });
    localStorage.setItem(currentUser + "_cart", JSON.stringify(cart));
    alert(productName + " added to cart!");
}

// Load Cart Items
function loadCart() {
    let currentUser = localStorage.getItem("currentUser");
    let cart = JSON.parse(localStorage.getItem(currentUser + "_cart")) || [];
    let cartDiv = document.getElementById("cart-items");
    let totalPrice = 0;

    cartDiv.innerHTML = "";
    if (cart.length === 0) {
        cartDiv.innerHTML = "<p>No items in cart.</p>";
    } else {
        cart.forEach(item => {
            cartDiv.innerHTML += `<p>${item.name} - ₹${item.price}</p>`;
            totalPrice += item.price;
        });
        document.getElementById("total-price").innerText = "Total: ₹" + totalPrice;
    }
}

// Checkout (Move Cart Items to Orders)
function checkout() {
    let currentUser = localStorage.getItem("currentUser");
    let cart = JSON.parse(localStorage.getItem(currentUser + "_cart")) || [];

    if (cart.length === 0) {
        alert("Cart is empty!");
        return;
    }

    let orders = JSON.parse(localStorage.getItem(currentUser + "_orders")) || [];
    orders.push(...cart);
    localStorage.setItem(currentUser + "_orders", JSON.stringify(orders));
    localStorage.removeItem(currentUser + "_cart");
    
    alert("Order Confirmed!");
    window.location.href = "orders.html";
}

// Load Orders
function loadOrders() {
    let currentUser = localStorage.getItem("currentUser");
    let orders = JSON.parse(localStorage.getItem(currentUser + "_orders")) || [];
    let orderDiv = document.getElementById("order-list");

    orderDiv.innerHTML = "";
    if (orders.length === 0) {
        orderDiv.innerHTML = "<p>No orders found.</p>";
    } else {
        orders.forEach(order => {
            orderDiv.innerHTML += `<p>${order.name} - ₹${order.price}</p>`;
        });
    }
}